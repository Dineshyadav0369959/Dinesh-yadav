const $ = id => document.getElementById(id);
const chat = $("chat");
const input = $("input");
const counter = $("counter");
const welcome = $("welcome");
const fileInput = $("fileInput");
const filePreview = $("filePreview");

let history = JSON.parse(localStorage.getItem("dineshAIHistory") || "[]");
let attachedText = "";
let busy = false;

function saveHistory() {
  localStorage.setItem("dineshAIHistory", JSON.stringify(history.slice(-40)));
}

function scrollDown() {
  setTimeout(() => chat.scrollTo({top: chat.scrollHeight, behavior: "smooth"}), 30);
}

function hideWelcome() {
  if (welcome) welcome.style.display = "none";
}

function addMessage(role, content, save = true) {
  hideWelcome();

  const row = document.createElement("div");
  row.className = `message ${role}`;

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "👤" : "🤖";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content;

  row.append(avatar, bubble);
  chat.appendChild(row);

  if (save) {
    history.push({role, content});
    saveHistory();
  }

  scrollDown();
}

function renderHistory() {
  chat.querySelectorAll(".message").forEach(x => x.remove());
  if (!history.length) return;

  hideWelcome();
  history.forEach(m => addMessage(m.role, m.content, false));
}

function showTyping() {
  const row = document.createElement("div");
  row.className = "message ai";
  row.id = "typing";

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = "🤖";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = '<div class="typing"><i></i><i></i><i></i></div>';

  row.append(avatar, bubble);
  chat.appendChild(row);
  scrollDown();
}

function removeTyping() {
  $("typing")?.remove();
}

function toast(message) {
  const t = $("toast");
  t.textContent = message;
  t.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => t.classList.remove("show"), 2400);
}

async function sendMessage() {
  if (busy) return;

  const text = input.value.trim();
  if (!text && !attachedText) return;

  let finalText = text;
  if (attachedText) {
    finalText += `\n\nAttached file content:\n${attachedText}`;
  }

  addMessage("user", finalText);
  input.value = "";
  attachedText = "";
  filePreview.innerHTML = "";
  updateCounter();

  busy = true;
  $("sendBtn").disabled = true;
  showTyping();

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({messages: history})
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "AI request failed.");
    }

    removeTyping();
    addMessage("assistant", data.answer);
    speak(data.answer);
  } catch (error) {
    removeTyping();
    addMessage("assistant", `⚠️ ${error.message}`, false);
    toast("AI request failed");
  } finally {
    busy = false;
    $("sendBtn").disabled = false;
  }
}

function updateCounter() {
  counter.textContent = `${input.value.length} / 8000`;
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 150) + "px";
}

input.addEventListener("input", updateCounter);
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

document.querySelectorAll(".quick-grid button").forEach(btn => {
  btn.addEventListener("click", () => {
    input.value = btn.dataset.prompt;
    updateCounter();
    sendMessage();
  });
});

$("newChat").onclick = () => {
  history = [];
  saveHistory();
  chat.querySelectorAll(".message").forEach(x => x.remove());
  welcome.style.display = "";
  toast("New chat started");
};

$("clearBtn").onclick = () => {
  history = [];
  saveHistory();
  chat.querySelectorAll(".message").forEach(x => x.remove());
  welcome.style.display = "";
  toast("Conversation cleared");
};

$("themeBtn").onclick = () => {
  document.body.classList.toggle("light");
  localStorage.setItem("dineshTheme",
    document.body.classList.contains("light") ? "light" : "dark");
};

if (localStorage.getItem("dineshTheme") === "light") {
  document.body.classList.add("light");
}

function openModal() {
  $("modal").classList.add("show");
}
function closeModal() {
  $("modal").classList.remove("show");
}
$("aboutBtn").onclick = openModal;
$("infoBtn").onclick = openModal;
$("closeModal").onclick = closeModal;
$("modal").onclick = e => {
  if (e.target === $("modal")) closeModal();
};

$("historyBtn").onclick = () => {
  if (history.length) {
    renderHistory();
    toast(`${history.length} saved messages loaded`);
  } else {
    toast("No saved history yet");
  }
};

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  if (file.size > 500000) {
    toast("File is too large. Use a file under 500 KB.");
    fileInput.value = "";
    return;
  }

  try {
    attachedText = await file.text();
    filePreview.innerHTML = `<span>📎 ${file.name} attached</span>`;
    toast("File attached");
  } catch {
    toast("Could not read the file");
  }
});

function startVoice() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    toast("Voice recognition is unavailable in this browser.");
    return;
  }

  const recognition = new Recognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;

  toast("Listening...");
  recognition.start();

  recognition.onresult = event => {
    input.value = event.results[0][0].transcript;
    updateCounter();
    toast("Voice captured");
  };

  recognition.onerror = () => toast("Voice recognition failed");
}

$("micBtn").onclick = startVoice;
$("voiceBtn").onclick = startVoice;

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(
    text.replace(/[*_#`]/g, "")
  );
  utterance.rate = 1;
  utterance.pitch = 1;
  speechSynthesis.speak(utterance);
}

async function healthCheck() {
  try {
    const r = await fetch("/api/health");
    const data = await r.json();

    $("connectionText").textContent =
      data.configured ? "AI ONLINE" : "API KEY NEEDED";
  } catch {
    $("connectionText").textContent = "SERVER OFFLINE";
  }
}

renderHistory();
healthCheck();