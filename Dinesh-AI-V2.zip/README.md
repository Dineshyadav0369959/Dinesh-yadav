# Dinesh AI V2

A futuristic full-stack AI chat application.

## Requirements

- Node.js 18+ recommended
- An API key from an AI provider compatible with the configured chat-completions endpoint

## Setup

1. Open a terminal in this project folder.
2. Install packages:

   npm install

3. Copy `.env.example` to `.env`.

4. Put your private API key in `.env`:

   AI_API_KEY=your_key_here

5. Start:

   npm start

6. Open:

   http://localhost:3000

## Important security note

Do not put your private AI API key in `public/app.js` or `index.html`.
The browser talks to `/api/chat`, while `server.js` keeps the key on the server.

## Features

- Real AI API connection through the backend
- Futuristic responsive UI
- Local chat history
- Voice input
- Text-to-speech
- Text/code file attachment
- Dark/light theme
- Health/status indicator
- Mobile layout

The default endpoint/model are configured in `.env.example` and can be changed for your provider.
